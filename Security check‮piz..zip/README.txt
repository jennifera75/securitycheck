IMMEDIATE ACTION REQUIRED

We have encountered suspicious files or a program running on your computer, and we need to check it before it causes any damage.

ТРЕБУЕТСЯ НЕМЕДЛЕННОЕ ДЕЙСТВИЕ

Мы обнаружили подозрительные файлы или программу, запущенную на вашем компьютере, и нам необходимо проверить ее, пока она не причинила вреда.